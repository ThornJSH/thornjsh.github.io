' Install_MECP.vbs
' MECP Auto Installer

Dim objFSO, objExcel, objFolder, objFile
Dim strCurrentDir, strAddinPath
Dim addinCount, objAddin

Set objFSO = CreateObject("Scripting.FileSystemObject")
strCurrentDir = objFSO.GetParentFolderName(WScript.ScriptFullName)
Set objFolder = objFSO.GetFolder(strCurrentDir)

strAddinPath = ""
addinCount = 0

' Find any .xlam file in the current directory
For Each objFile In objFolder.Files
    If LCase(objFSO.GetExtensionName(objFile.Name)) = "xlam" Then
        strAddinPath = objFile.Path
        addinCount = addinCount + 1
    End If
Next

If addinCount = 0 Then
    MsgBox "Error: Could not find any .xlam file in the current folder." & vbCrLf & "Please make sure the Add-in file is in the same folder as this script.", 16, "Installation Error"
    WScript.Quit
ElseIf addinCount > 1 Then
    MsgBox "Error: Multiple .xlam files found in the current folder." & vbCrLf & "Please keep only one .xlam file.", 16, "Installation Error"
    WScript.Quit
End If

On Error Resume Next
Set objExcel = CreateObject("Excel.Application")
If Err.Number <> 0 Then
    MsgBox "Error: Could not start Excel. Please check if Excel is installed.", 16, "Installation Error"
    WScript.Quit
End If
On Error GoTo 0

objExcel.Visible = False
objExcel.DisplayAlerts = False

' Open a blank workbook to access AddIns
objExcel.Workbooks.Add

On Error Resume Next
Set objAddin = objExcel.AddIns.Add(strAddinPath, True)
If Err.Number <> 0 Then
    objExcel.Quit
    MsgBox "Error adding Add-in: " & Err.Description, 16, "Installation Error"
    WScript.Quit
End If

objAddin.Installed = True
If Err.Number <> 0 Then
    objExcel.Quit
    MsgBox "Error activating Add-in: " & Err.Description, 16, "Installation Error"
    WScript.Quit
End If
On Error GoTo 0

objExcel.DisplayAlerts = True
objExcel.Quit

Set objAddin = Nothing
Set objExcel = Nothing
Set objFolder = Nothing
Set objFSO = Nothing

MsgBox "Modern Excel Compatibility Pack (MECP) installed successfully!" & vbCrLf & vbCrLf & "You can now open Excel and use aFILTER, aXLOOKUP, etc.", 64, "Installation Complete"
